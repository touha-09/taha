#include "game.h"

int main(int argc, char* argv[]) {
    SDL_Surface* screen = NULL;
    SDL_Surface* bg = NULL;
    PuzzlePiece pieces[NUM_PIECES];
    int quit = 0;

    if (SDL_Init(SDL_INIT_VIDEO) != 0) {
        printf("Erreur SDL_Init: %s\n", SDL_GetError());
        return 1;
    }

    screen = SDL_SetVideoMode(SCREEN_WIDTH, SCREEN_HEIGHT, 32, SDL_SWSURFACE);
    if (!screen) {
        printf("Erreur SetVideoMode: %s\n", SDL_GetError());
        SDL_Quit();
        return 1;
    }
    SDL_WM_SetCaption("Pyramids of Giza", NULL);

    bg = loadImage("assets/bg.bmp");
    initPieces(pieces);

    SDL_Event event;
    while (!quit) {
        while (SDL_PollEvent(&event)) {
            handleEvents(&event, pieces, &quit);
        }

        drawPieces(screen, bg, pieces);
        SDL_Delay(16);
    }

    SDL_Quit();
    return 0;
}
