#include "game.h"
#include <stdio.h>

SDL_Surface* loadImage(const char* path) {
    SDL_Surface* loaded = SDL_LoadBMP(path);
    if (!loaded) {
        printf("Erreur chargement image %s: %s\n", path, SDL_GetError());
        return NULL;
    }
    return SDL_DisplayFormat(loaded);
}

void initPieces(PuzzlePiece pieces[]) {
    pieces[0].image = loadImage("assets/chest.bmp");
    pieces[0].position.x = 100;
    pieces[0].position.y = 500;
    pieces[0].isBomb = 0;
    pieces[0].dragging = 0;

    pieces[1].image = loadImage("assets/star.bmp");
    pieces[1].position.x = 300;
    pieces[1].position.y = 500;
    pieces[1].isBomb = 0;
    pieces[1].dragging = 0;

    pieces[2].image = loadImage("assets/bomb.bmp");
    pieces[2].position.x = 500;
    pieces[2].position.y = 500;
    pieces[2].isBomb = 1;
    pieces[2].dragging = 0;
}

void drawPieces(SDL_Surface* screen, SDL_Surface* bg, PuzzlePiece pieces[]) {
    SDL_BlitSurface(bg, NULL, screen, NULL);
    for (int i = 0; i < NUM_PIECES; i++) {
        SDL_BlitSurface(pieces[i].image, NULL, screen, &pieces[i].position);
    }
    SDL_Flip(screen);
}

void handleEvents(SDL_Event* event, PuzzlePiece pieces[], int* quit) {
    switch (event->type) {
        case SDL_QUIT:
            *quit = 1;
            break;
        case SDL_MOUSEBUTTONDOWN:
            for (int i = 0; i < NUM_PIECES; i++) {
                SDL_Rect r = pieces[i].position;
                if (event->button.x >= r.x && event->button.x <= r.x + 64 &&
                    event->button.y >= r.y && event->button.y <= r.y + 64) {
                    pieces[i].dragging = 1;
                }
            }
            break;
        case SDL_MOUSEBUTTONUP:
            for (int i = 0; i < NUM_PIECES; i++) {
                pieces[i].dragging = 0;
            }
            break;
        case SDL_MOUSEMOTION:
            for (int i = 0; i < NUM_PIECES; i++) {
                if (pieces[i].dragging) {
                    pieces[i].position.x = event->motion.x - 32;
                    pieces[i].position.y = event->motion.y - 32;
                }
            }
            break;
    }
}
