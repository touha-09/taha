#include "fichier.h"

int main(int argc, char** argv) {
    SDL_Surface *ecran;
    background b1;
    SDL_Surface *images[5];
    SDL_Rect positions[5];
    int quitter = 1;
    Mix_Chunk *clickSound; // Use Mix_Chunk for sound effects

    initialiserSDL(&ecran, &b1);
    chargerImageBouton1(&images[0]);
    chargerImageBouton2(&images[1]);
    chargerImageBouton3(&images[2]);
    chargerImageBouton4(&images[3]);
    chargerImageBouton5(&images[4]);

    definirPosition(&positions[0], 5, 200);
    definirPosition(&positions[1], 5, 250);
    definirPosition(&positions[2], 5, 300);
    definirPosition(&positions[3], 5, 350);
    definirPosition(&positions[4], 1000, 500);
    TTF_Init();
    TTF_Font *font = TTF_OpenFont("arial.ttf", 20);
    if (font == NULL) {
        printf("Erreur: Impossible de charger la police: %s\n", TTF_GetError());
        exit(1);
    }

    // Load sound effect using Mix_LoadWAV
    clickSound = Mix_LoadWAV("sonbref (1).wav");
    if (clickSound == NULL) {
        printf("Erreur: Impossible de charger le son: %s\n", Mix_GetError());
        exit(1);
    }

    Mix_PlayMusic(b1.musique, -1); // Play background music

    while (quitter) {
        gererEvenements(&quitter, images, positions, clickSound, font, ecran);
        afficher(ecran, b1, images, positions, font);
    }

    nettoyer(images, &b1, font);
    Mix_FreeChunk(clickSound); // Free the sound effect
    return 0;
}
