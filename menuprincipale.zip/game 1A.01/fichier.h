#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

typedef struct background {
    SDL_Rect posback;
    SDL_Surface *imgback;
    Mix_Music *musique;
} background;

typedef struct bouton {
    SDL_Rect posbouton;
    SDL_Surface *imgbouton[2];
} bouton;

void initialiserSDL(SDL_Surface **ecran, background *b1);
void initback(background *b);
void chargerImageBouton1(SDL_Surface **image);
void chargerImageBouton2(SDL_Surface **image);
void chargerImageBouton3(SDL_Surface **image);
void chargerImageBouton4(SDL_Surface **image);
void chargerImageBouton5(SDL_Surface **image);
void definirPosition(SDL_Rect *position, int x, int y);
void afficherback(background b, SDL_Surface *ecran);
void afficher(SDL_Surface *ecran, background b1, SDL_Surface **images, SDL_Rect *positions, TTF_Font *font);
void gererEvenements(int *quitter, SDL_Surface **images, SDL_Rect *positions, Mix_Chunk *clickSound, TTF_Font *font, SDL_Surface *ecran);
void nettoyer(SDL_Surface **images, background *b1, TTF_Font *font);
void libererback(background *b);
