#include "fichier.h"

// Fonction pour initialiser SDL et les ressources de fond
void initialiserSDL(SDL_Surface **ecran, background *b1) {
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
        fprintf(stderr, "Echec de l'initialisation de SDL: %s\n", SDL_GetError());
        exit(1);
    }

    // Initialiser SDL_Mixer pour la gestion des sons
    if (Mix_OpenAudio(22050, MIX_DEFAULT_FORMAT, 2, 4096) == -1) {
        printf("Erreur: Impossible d'initialiser SDL_Mixer: %s\n", Mix_GetError());
        exit(1);
    }

    initback(b1);
    *ecran = SDL_SetVideoMode(b1->imgback->w, b1->imgback->h, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    if (*ecran == NULL) {
        fprintf(stderr, "Echec de la création de la fenêtre: %s\n", SDL_GetError());
        exit(1);
    }
}
// Fonction pour initialiser le fond d'écran et la musique
void initback(background *b) {
    // Charger l'image de fond
    b->imgback = IMG_Load("background.png");
    if (!b->imgback) {
        printf("Erreur: Impossible de charger background.png ! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }

    // Initialiser la musique de fond
    b->musique = Mix_LoadMUS("011.mp3");
    if (!b->musique) {
        printf("Erreur: Impossible de charger la musique ! SDL_Error: %s\n", Mix_GetError());
        exit(1);
    }
}

// Fonction pour charger les images des boutons
void chargerImageBouton1(SDL_Surface **image) {
    *image = IMG_Load("start1.png");
    if (*image == NULL) {
        printf("Erreur: Impossible de charger start.png ! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }
}

void chargerImageBouton2(SDL_Surface **image) {
    *image = IMG_Load("seeting1.png");
    if (*image == NULL) {
        printf("Erreur: Impossible de charger setting.png ! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }
}

void chargerImageBouton3(SDL_Surface **image) {
    *image = IMG_Load("high score1.png");
    if (*image == NULL) {
        printf("Erreur: Impossible de charger high score.png ! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }
}

void chargerImageBouton4(SDL_Surface **image) {
    *image = IMG_Load("history1.png");
    if (*image == NULL) {
        printf("Erreur: Impossible de charger history.png ! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }

}

void chargerImageBouton5(SDL_Surface **image) {
    *image = IMG_Load("quit1.png");
    if (*image == NULL) {
        printf("Erreur: Impossible de charger quit.png ! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }
}

// Fonction pour définir la position d'un bouton
void definirPosition(SDL_Rect *position, int x, int y) {
    position->x = x;
    position->y = y;
}

// Fonction pour afficher le fond d'écran
void afficherback(background b, SDL_Surface *ecran) {        
    SDL_BlitSurface(b.imgback, NULL, ecran, &b.posback);
}

// Fonction pour afficher tous les éléments à l'écran
void afficher(SDL_Surface *ecran, background b1, SDL_Surface **images, SDL_Rect *positions, TTF_Font *font) {
    afficherback(b1, ecran);
    
    for (int i = 0; i < 5; i++) {
        SDL_BlitSurface(images[i], NULL, ecran, &positions[i]);
    }
    
    SDL_Color textColor = {255, 255, 255};                                          //nahitha
    SDL_Surface *surfaceTexte = TTF_RenderText_Solid(font, "", textColor);          //nahitha
    SDL_Rect positiontext = {500, 125};                                             //nahitha
    SDL_BlitSurface(surfaceTexte, NULL, ecran, &positiontext);                      //nahitha
    SDL_FreeSurface(surfaceTexte);
    
    SDL_Flip(ecran);
}

// Fonction pour gérer les événements (clics sur les boutons)
void gererEvenements(int *quitter, SDL_Surface **images, SDL_Rect *positions, Mix_Chunk *clickSound, TTF_Font *font, SDL_Surface *ecran) {
    SDL_Event event;
    int x, y;

    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT || (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE)) {
            *quitter = 0;  // Quitter si on ferme la fenêtre ou appuie sur ESC
        }

        // Vérification du clic de la souris
        if (event.type == SDL_MOUSEBUTTONDOWN) {
            x = event.button.x;
            y = event.button.y;

            // Vérifier si le bouton "Quitter" (button 5) est cliqué
            if (x >= positions[4].x && x <= positions[4].x + images[4]->w &&
                y >= positions[4].y && y <= positions[4].y + images[4]->h) {
                *quitter = 0;  // Si le bouton Quitter est cliqué, quitter le programme
            }

            // Vérifier si le bouton "Histoire" (button 4) est cliqué
            if (x >= positions[3].x && x <= positions[3].x + images[3]->w &&
                y >= positions[3].y && y <= positions[3].y + images[3]->h) {
                *quitter = 0;  // Si le bouton Histoire est cliqué, quitter le programme
            }

            // Jouer le son de clic
            Mix_PlayChannel(-1, clickSound, 0);
        }
    }
}

// Fonction pour libérer les ressources
void nettoyer(SDL_Surface **images, background *b1, TTF_Font *font) {
    for (int i = 0; i < 5; i++) {
        SDL_FreeSurface(images[i]);
    }
    libererback(b1);
    TTF_CloseFont(font);
    TTF_Quit();
    SDL_Quit();
}

// Fonction pour libérer les ressources du fond d'écran
void libererback(background *b) {
    SDL_FreeSurface(b->imgback);
    Mix_FreeMusic(b->musique);
}
