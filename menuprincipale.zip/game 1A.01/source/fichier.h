#ifndef FICHIER_H  // Garde-fou pour éviter les inclusions multiples
#define FICHIER_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>

// Déclaration des structures

typedef struct {
    SDL_Surface *ecran;
    SDL_Surface *background;
    SDL_Surface *playBtn;
    SDL_Surface *playBtnHover;
    SDL_Surface *quitBtn;
    SDL_Surface *quitBtnHover;
    SDL_Rect posBackground;
    SDL_Rect posPlayBtn;
    SDL_Rect posQuitBtn;
    int quitter;
    int playHovered;
    int quitHovered;
} MenuPrincipal;

typedef struct {
    SDL_Surface *ecran;
    SDL_Surface *background;
    SDL_Surface *quizboutton;
    SDL_Surface *quizbouttonHover;
    SDL_Surface *puzzleboutton;
    SDL_Surface *puzzlebouttonHover;
    SDL_Surface *question;
    SDL_Surface *aboutton;
    SDL_Surface *abouttonHover;
    SDL_Surface *bboutton;
    SDL_Surface *bbouttonHover;
    SDL_Surface *cboutton;
    SDL_Surface *cbouttonHover;
    Mix_Music *musique;
    Mix_Chunk *brefMusique;
    TTF_Font *font;
    SDL_Color textColor;
    SDL_Surface *surfaceTexte;
    SDL_Rect posBackground;
    SDL_Rect posQuizBtn;
    SDL_Rect posPuzzleBtn;
    SDL_Rect posQuestion;
    SDL_Rect posA;
    SDL_Rect posB;
    SDL_Rect posC;
    SDL_Rect posText;
    int quitter;
    int play;
    int quizHovered;
    int puzzleHovered;
    int quizWasHovered;
    int puzzleWasHovered;
    int aHovered;
    int bHovered;
    int cHovered;
    int aWasHovered;
    int bWasHovered;
    int cWasHovered;
} SubMenuEnigme;

// Déclarations des fonctions

void initMenuPrincipal(MenuPrincipal *menu);
void displayMenuPrincipal(MenuPrincipal *menu);
void cleanupMenuPrincipal(MenuPrincipal *menu);

int collision_avec_souris(SDL_Rect pos_btn);

void initSubMenu(SubMenuEnigme *menu);
void displaySubMenu(SubMenuEnigme *menu);
void cleanupSubMenu(SubMenuEnigme *menu);

#endif  // FICHIER_H

