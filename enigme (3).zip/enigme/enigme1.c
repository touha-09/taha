#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_image.h>
#include "enigme1.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include "cJSON.h"
#include <SDL/SDL_rotozoom.h>  // NÉCESSAIRE pour la rotation (SDL_gfx)

static int questions_posees[MAX_QUESTIONS] = {0};
static time_t start_time;

int charger_enigmes_depuis_fichier(EnigmeManager *manager, const char *filename) {
    FILE *file = fopen(filename, "r");
    if (!file) {
        perror("Erreur ouverture fichier JSON");
        return 0;
    }

    fseek(file, 0, SEEK_END);
    long taille = ftell(file);
    rewind(file);

    char *contenu = malloc(taille + 1);
    fread(contenu, 1, taille, file);
    contenu[taille] = '\0';
    fclose(file);

    cJSON *json = cJSON_Parse(contenu);
    if (!json) {
        printf("Erreur JSON : %s\n", cJSON_GetErrorPtr());
        free(contenu);
        return 0;
    }

    cJSON *questions = cJSON_GetObjectItem(json, "questions");
    int nb_questions = cJSON_GetArraySize(questions);
    manager->total_questions = nb_questions;

    for (int i = 0; i < nb_questions; i++) {
        cJSON *q = cJSON_GetArrayItem(questions, i);
        strcpy(manager->questions[i].question, cJSON_GetObjectItem(q, "question")->valuestring);

        cJSON *choices = cJSON_GetObjectItem(q, "choices");
        for (int j = 0; j < MAX_CHOICES; j++) {
            strcpy(manager->questions[i].choices[j], cJSON_GetArrayItem(choices, j)->valuestring);
        }

        manager->questions[i].correct_choice = cJSON_GetObjectItem(q, "correct_choice")->valueint;
    }

    cJSON_Delete(json);
    free(contenu);
    return 1;
}

// Helper function to initialize SDL and TTF
int initialize_sdl(SDL_Surface **screen, const char *title, int width, int height) {
    if (SDL_Init(SDL_INIT_VIDEO) < 0) {
        printf("Erreur initialisation SDL: %s\n", SDL_GetError());
        return 0;
    }

    if (TTF_Init() == -1) {
        printf("Erreur initialisation SDL_ttf: %s\n", TTF_GetError());
        SDL_Quit();
        return 0;
    }

    *screen = SDL_SetVideoMode(width, height, 32, SDL_HWSURFACE);
    if (!*screen) {
        printf("Erreur création écran SDL: %s\n", SDL_GetError());
        TTF_Quit();
        SDL_Quit();
        return 0;
    }

    SDL_WM_SetCaption(title, NULL);
    return 1;
}

// Helper function to load an image
SDL_Surface* load_image(const char *path) {
    SDL_Surface *image = IMG_Load(path);
    if (!image) {
        printf("Erreur chargement image %s: %s\n", path, IMG_GetError());
    }
    return image;
}

// Helper function to load a font
TTF_Font* load_font(const char *path, int size) {
    TTF_Font *font = TTF_OpenFont(path, size);
    if (!font) {
        printf("Erreur chargement police %s: %s\n", path, TTF_GetError());
    }
    return font;
}

// Helper function to clean up SDL resources
void cleanup_sdl(SDL_Surface *background, SDL_Surface *btn_image, TTF_Font *font) {
    if (background) SDL_FreeSurface(background);
    if (btn_image) SDL_FreeSurface(btn_image);
    if (font) TTF_CloseFont(font);
    TTF_Quit();
    SDL_Quit();
}

// Helper function to render text dynamically
SDL_Surface* render_text(TTF_Font *font, const char *text, SDL_Color color) {
    return TTF_RenderText_Solid(font, text, color);
}

// Helper function to center an SDL_Rect horizontally
SDL_Rect center_rect_horizontally(SDL_Rect rect, int screen_width) {
    rect.x = (screen_width - rect.w) / 2;
    return rect;
}

// Helper function to display a background image scaled to fit the screen
void display_scaled_background(SDL_Surface *screen, SDL_Surface *bg_img) {
    SDL_Surface *scaled_bg = SDL_CreateRGBSurface(0, screen->w, screen->h, screen->format->BitsPerPixel,
                                                  screen->format->Rmask, screen->format->Gmask, screen->format->Bmask, screen->format->Amask);
    SDL_Rect dest_rect = {0, 0, screen->w, screen->h};
    SDL_BlitSurface(bg_img, NULL, scaled_bg, &dest_rect);
    SDL_BlitSurface(scaled_bg, NULL, screen, NULL);
    SDL_FreeSurface(scaled_bg);
}

// Function to display a question and its choices
void afficher_enigme(SDL_Surface *screen, SDL_Surface *bg_img, SDL_Surface *btn_img, TTF_Font *font, Enigme *enigme, SDL_Rect zones[]) {
    SDL_Color color = {0, 0, 0}; // Black text
    SDL_Surface *text;
    SDL_Rect pos;

    // Display the background scaled to fit the screen
    SDL_Rect dest_rect = {0, 0, screen->w, screen->h};
    display_scaled_background(screen, bg_img);

    // Display the question with a button background dynamically sized to fit the text
    text = render_text(font, enigme->question, color);
    SDL_Surface *question_bg = SDL_CreateRGBSurface(0, text->w + 20, text->h + 20, screen->format->BitsPerPixel,
                                                     screen->format->Rmask, screen->format->Gmask, screen->format->Bmask, screen->format->Amask);
    SDL_FillRect(question_bg, NULL, SDL_MapRGB(screen->format, 200, 200, 200)); // Light gray background

    pos.x = (screen->w - question_bg->w) / 2; // Center horizontally
    pos.y = 20; // Top margin
    SDL_BlitSurface(question_bg, NULL, screen, &pos);
    SDL_FreeSurface(question_bg);

    pos.x += 10; // Add padding for the text
    pos.y += 10;

    SDL_BlitSurface(text, NULL, screen, &pos);
    SDL_FreeSurface(text);

    int y = 150; // Starting y position for options

    for (int i = 0; i < MAX_CHOICES; i++) {
        // Display the button dynamically sized to fit the text
        text = render_text(font, enigme->choices[i], color);
        SDL_Surface *choice_bg = SDL_CreateRGBSurface(0, btn_img->w, btn_img->h, screen->format->BitsPerPixel,
                                                       screen->format->Rmask, screen->format->Gmask, screen->format->Bmask, screen->format->Amask);
        SDL_BlitSurface(btn_img, NULL, choice_bg, NULL); // Use btn_img as the button background

        pos.x = (screen->w - choice_bg->w) / 2;
        pos.y = y;
        SDL_BlitSurface(choice_bg, NULL, screen, &pos);
        SDL_FreeSurface(choice_bg);

        SDL_Rect text_pos;
        text_pos.x = pos.x + (btn_img->w - text->w) / 2; // Center text horizontally within the button
        text_pos.y = pos.y + (btn_img->h - text->h) / 2; // Center text vertically within the button
        SDL_BlitSurface(text, NULL, screen, &text_pos);

        // Store the button zone
        zones[i] = pos;
        zones[i].w = btn_img->w;
        zones[i].h = btn_img->h;

        SDL_FreeSurface(text);
        y += btn_img->h + 20; // Space between buttons
    }

    SDL_Flip(screen);
}

void afficher_resultat(SDL_Surface *screen, TTF_Font *font, int correct) {
    SDL_Surface *result_bg;
    SDL_Surface *message;
    SDL_Color color = {255, 255, 255}; // White text

    if (correct) {
        animer_message_zoom(screen, "Good job!", color, "les images/1x/bg_e.png");
    } else {
        animer_message_zoom(screen, "Game Over! Bad answer", color, "les images/1x/bg_e.png");
    }
    
}

int afficher_enigme_avec_timer(SDL_Surface *screen, SDL_Surface *bg_img, SDL_Surface *btn_img, SDL_Surface *btn_img_hover, TTF_Font *font, Enigme *enigme, SDL_Rect zones[], int temps_ecoule, int time_limit) {
    SDL_Color color = {0, 0, 0}; // Black text
    SDL_Surface *text;
    SDL_Rect pos;

    // Afficher le background
    display_scaled_background(screen, bg_img);

    // Question principale
    // Question principale (sans fond)
    text = render_text(font, enigme->question, color);
    pos.x = (screen->w - text->w) / 2;
    pos.y = 20;
    SDL_BlitSurface(text, NULL, screen, &pos);
    SDL_FreeSurface(text);


    int y = 150;
    int mouse_x, mouse_y;
SDL_GetMouseState(&mouse_x, &mouse_y);

for (int i = 0; i < MAX_CHOICES; i++) {
    // Détecte si la souris est sur ce bouton
    pos.x = (screen->w - btn_img->w) / 2;
    pos.y = y;

    int survol = (mouse_x >= pos.x && mouse_x <= pos.x + btn_img->w &&
                  mouse_y >= pos.y && mouse_y <= pos.y + btn_img->h);

    // Change la couleur si hover
    SDL_Color btn_color = survol ? (SDL_Color){255, 0, 0} : (SDL_Color){255, 255, 255};  // rouge si hover

    // Crée le texte avec la bonne couleur
    text = render_text(font, enigme->choices[i], btn_color);

    // Affiche le bouton
    if (survol && btn_img_hover) {
    SDL_BlitSurface(btn_img_hover, NULL, screen, &pos);
} else {
    SDL_BlitSurface(btn_img, NULL, screen, &pos);
}


    // Affiche le texte centré
    SDL_Rect text_pos;
    text_pos.x = pos.x + (btn_img->w - text->w) / 2;
    text_pos.y = pos.y + (btn_img->h - text->h) / 2;
    SDL_BlitSurface(text, NULL, screen, &text_pos);

    zones[i] = pos;
    zones[i].w = btn_img->w;
    zones[i].h = btn_img->h;

    SDL_FreeSurface(text);
    y += btn_img->h + 20;
}



    // 🕒 TIMER directement ici
    int time_remaining = time_limit - temps_ecoule;
    if (time_remaining < 0) {
        time_remaining = 0;
    }
    char path[50];
    sprintf(path, "timer/%d.png", time_remaining);
    SDL_Surface *timer_image = load_image(path);
    if (timer_image) {
        SDL_Rect timer_pos;
        timer_pos.x = 20;
        timer_pos.y = 20;
        SDL_BlitSurface(timer_image, NULL, screen, &timer_pos);
        SDL_FreeSurface(timer_image);
    }

    SDL_Flip(screen);

    return (time_remaining == 0);  // return 1 si le temps est fini
}



int generer_enigme_unique(EnigmeManager *manager) { 
    srand(time(NULL));
    if (manager->total_questions <= 0) return -1;

    int index;
    do {
        index = rand() % manager->total_questions;
    } while (questions_posees[index] == 1);

    // Reset all questions as unasked if all have been asked
    int all_asked = 1;
    for (int i = 0; i < manager->total_questions; i++) {
        if (questions_posees[i] == 0) {
            all_asked = 0;
            break;
        }
    }

    if (all_asked) {
        memset(questions_posees, 0, sizeof(questions_posees));
    }

    questions_posees[index] = 1;
    manager->current_index = index;
    return index;
}

int verifier_reponse(Enigme *enigme, int choix_utilisateur) {
    return choix_utilisateur == enigme->correct_choice;
}

void mettre_a_jour_score(EnigmeManager *manager, int est_correct) {
    if (est_correct) {
        manager->score += 10;
        manager->level += 1;
    } else {
        manager->lives -= 1;
    }
}

void demarrer_chronometre() {
    start_time = time(NULL);
}

int temps_ecoule() {
    return (int)(time(NULL) - start_time);
}




void animer_message_zoom(SDL_Surface *screen, const char *message_text, SDL_Color color, const char *background_path) {
    int min_size = 24;  // taille minimale
    int max_size = 72;  // taille maximale
    int zoom_steps = 20;

    SDL_Surface *background = load_image(background_path);

    for (int i = 0; i < 2; i++) {  // deux cycles : zoom in + zoom out
        for (int step = 0; step <= zoom_steps; step++) {
            int size = min_size + (step * (max_size - min_size)) / zoom_steps;
            double angle = step * (360.0 / zoom_steps);  // rotation complète en un cycle

            TTF_Font *font = load_font("font/THEBOLDFONT.ttf", size);
            SDL_Surface *message = TTF_RenderText_Solid(font, message_text, color);

            // Appliquer la rotation + garder l'échelle normale (zoom = 1.0)
            SDL_Surface *rotated = rotozoomSurface(message, angle, 1.0, 1);

            if (background) {
                SDL_BlitSurface(background, NULL, screen, NULL);
            } else {
                SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));  // fallback noir
            }

            SDL_Rect pos;
            pos.x = (screen->w - rotated->w) / 2;
            pos.y = (screen->h - rotated->h) / 2;
            SDL_BlitSurface(rotated, NULL, screen, &pos);

            SDL_Flip(screen);

            SDL_FreeSurface(message);
            SDL_FreeSurface(rotated);
            TTF_CloseFont(font);
            SDL_Delay(30);
        }

        // zoom out + rotation inverse
        for (int step = zoom_steps; step >= 0; step--) {
            int size = min_size + (step * (max_size - min_size)) / zoom_steps;
            double angle = step * (360.0 / zoom_steps);

            TTF_Font *font = load_font("font/THEBOLDFONT.ttf", size);
            SDL_Surface *message = TTF_RenderText_Solid(font, message_text, color);

            SDL_Surface *rotated = rotozoomSurface(message, angle, 1.0, 1);

            if (background) {
                SDL_BlitSurface(background, NULL, screen, NULL);
            } else {
                SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
            }

            SDL_Rect pos;
            pos.x = (screen->w - rotated->w) / 2;
            pos.y = (screen->h - rotated->h) / 2;
            SDL_BlitSurface(rotated, NULL, screen, &pos);

            SDL_Flip(screen);

            SDL_FreeSurface(message);
            SDL_FreeSurface(rotated);
            TTF_CloseFont(font);
            SDL_Delay(30);
        }
    }

    if (background) SDL_FreeSurface(background);
}




void afficher_ecran_restart(SDL_Surface *screen, SDL_Surface *bg_restart, SDL_Surface *btn_restart, SDL_Surface *btn_restart_hover, TTF_Font *font, SDL_Rect *zone_restart) {
    int mouse_x, mouse_y;
    SDL_GetMouseState(&mouse_x, &mouse_y);

    if (bg_restart) {
        SDL_BlitSurface(bg_restart, NULL, screen, NULL);
    } else {
        SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 100, 100, 100));
    }

    SDL_Rect pos;
    pos.x = (screen->w - btn_restart->w) / 2;
    pos.y = (screen->h - btn_restart->h) / 2;

    // Utiliser l'image hover si la souris est dessus
    int survol = (mouse_x >= pos.x && mouse_x <= pos.x + btn_restart->w &&
                  mouse_y >= pos.y && mouse_y <= pos.y + btn_restart->h);

    if (survol && btn_restart_hover) {
        SDL_BlitSurface(btn_restart_hover, NULL, screen, &pos);
    } else {
        SDL_BlitSurface(btn_restart, NULL, screen, &pos);
    }

    // Texte sur le bouton
    SDL_Color color = {255, 255, 255};  // blanc
    SDL_Surface *text = TTF_RenderText_Solid(font, "Restart", color);
    SDL_Rect text_pos;
    text_pos.x = pos.x + (btn_restart->w - text->w) / 2;
    text_pos.y = pos.y + (btn_restart->h - text->h) / 2;
    SDL_BlitSurface(text, NULL, screen, &text_pos);

    SDL_Flip(screen);

    *zone_restart = pos;

    SDL_FreeSurface(text);
}

