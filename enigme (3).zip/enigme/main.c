#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include "enigme1.h"
#include <SDL/SDL_rotozoom.h>  // NÉCESSAIRE pour la rotation (SDL_gfx)

int main(int argc, char *argv[]) {
    SDL_Surface *screen;
    if (!initialize_sdl(&screen, "Enigme Game", 800, 600)) {
        return 1;
    }

    SDL_Surface *background = load_image("les images/1x/bg_e.png");
    SDL_Surface *btn_image = load_image("les images/1x/1x/btnfinal.png");
    SDL_Surface *bg_restart = load_image("les images/1x/bg_e.png");  // ton image spéciale
    SDL_Surface *btn_restart = load_image("les images/1x/1x/btnfinal.png");  // bouton Restart
    SDL_Surface *btn_restart_hover = load_image("les images/1x/1x/bntfinal2.png");
    SDL_Surface *btn_img_hover = load_image("les images/1x/1x/bntfinal2.png");

    if (Mix_OpenAudio(44100, MIX_DEFAULT_FORMAT, 2, 2048) < 0) {
    printf("Erreur initialisation SDL_mixer : %s\n", Mix_GetError());
}
    Mix_Chunk *click_sound = Mix_LoadWAV("audio/mixkit-on-or-off-light-switch-tap-2585.wav");
    if (!click_sound) {
        printf("Erreur chargement son : %s\n", Mix_GetError());
    }



    if (!bg_restart || !btn_restart) {
        printf("Erreur chargement images restart\n");
        cleanup_sdl(background, btn_image, NULL);
        return 1;
    }


    if (!background || !btn_image) {
        cleanup_sdl(background, btn_image, NULL);
        return 1;
    }

    TTF_Font *font = load_font("font/THEBOLDFONT.ttf", 24);
    if (!font) {
        cleanup_sdl(background, btn_image, NULL);
        return 1;
    }

    EnigmeManager manager = {0};
    manager.lives = 3;
    manager.level = 1;
    manager.score = 0;

    if (!charger_enigmes_depuis_fichier(&manager, "questions.json")) {
        printf("Erreur de chargement des énigmes depuis le fichier JSON\n");
        return 1;
    }

    SDL_Event event;
    int quitter = 0;

    // Générer une seule question aléatoire
// Boucle pour afficher 3 questions maximum
    for (int q = 0; q < 3; q++) {
        if (quitter) break;

        int index = generer_enigme_unique(&manager);
        if (index == -1) {
            printf("Plus de questions disponibles\n");
            break;
        }

        Enigme *e = &manager.questions[index];
        SDL_Rect zones[MAX_CHOICES];
        demarrer_chronometre();

        int repondu = 0;
        while (!repondu) {
            while (SDL_PollEvent(&event)) {
                if (event.type == SDL_QUIT) {
                    quitter = 1;
                    repondu = 1;  // Quitter si on ferme la fenêtre
                }

                if (event.type == SDL_MOUSEBUTTONDOWN && event.button.button == SDL_BUTTON_LEFT) {
                    int x = event.button.x;
                    int y = event.button.y;

                    for (int i = 0; i < MAX_CHOICES; i++) {
                        if (x >= zones[i].x && x <= zones[i].x + zones[i].w &&
                            y >= zones[i].y && y <= zones[i].y + zones[i].h) {
                                
                            if (click_sound) Mix_PlayChannel(-1, click_sound, 0);

                            int correct = verifier_reponse(e, i);
                            afficher_resultat(screen, font, correct);
                        
                            if (correct) {
                                // Bonne réponse : on passe à la suivante normalement
                                repondu = 1;
                            } else {
                                // Mauvaise réponse : afficher écran restart et attendre clic
                                int restart = 0;
                                SDL_Rect zone_restart;
                        
                                while (!restart) {
                                    afficher_ecran_restart(screen, bg_restart, btn_restart, btn_restart_hover, font, &zone_restart);
                                    SDL_Event restart_event;
                                    while (SDL_PollEvent(&restart_event)) {
                                        if (restart_event.type == SDL_QUIT) {
                                            quitter = 1;
                                            restart = 1;
                                            repondu = 1;  // On sort aussi de la question actuelle
                                        }
                                        if (restart_event.type == SDL_MOUSEBUTTONDOWN && restart_event.button.button == SDL_BUTTON_LEFT) {
                                            int rx = restart_event.button.x;
                                            int ry = restart_event.button.y;
                                            if (rx >= zone_restart.x && rx <= zone_restart.x + zone_restart.w &&
                                                ry >= zone_restart.y && ry <= zone_restart.y + zone_restart.h) {

                                                if (click_sound) Mix_PlayChannel(-1, click_sound, 0);

                                                // Cliqué sur Restart : recommence le jeu depuis le début
                                                q = -1;  // réinitialise la boucle des questions
                                                restart = 1;
                                                repondu = 1;
                                                break;
                                            }
                                        }
                                    }
                                    SDL_Delay(50);  // éviter la boucle trop rapide
                                }
                            }
                            break;
                        }
                        
                    }
                }
            }

            if (!quitter) {
                int temps_fini = afficher_enigme_avec_timer(screen, background, btn_image, btn_img_hover, font, e, zones, temps_ecoule(), 12);


    if (temps_fini) {
        // Afficher écran Restart spécial temps fini
        int restart = 0;
        SDL_Rect zone_restart;

        while (!restart) {
            afficher_ecran_restart(screen, bg_restart, btn_restart, btn_restart_hover, font, &zone_restart);
            SDL_Event restart_event;
            while (SDL_PollEvent(&restart_event)) {
                if (restart_event.type == SDL_QUIT) {
                    quitter = 1;
                    restart = 1;
                    repondu = 1;
                }
                if (restart_event.type == SDL_MOUSEBUTTONDOWN && restart_event.button.button == SDL_BUTTON_LEFT) {
                    int rx = restart_event.button.x;
                    int ry = restart_event.button.y;
                    if (rx >= zone_restart.x && rx <= zone_restart.x + zone_restart.w &&
                        ry >= zone_restart.y && ry <= zone_restart.y + zone_restart.h) {
                        // Cliqué sur Restart : recommencer le jeu depuis le début
                        q = -1;  // repartir à zéro
                        restart = 1;
                        repondu = 1;
                        break;
                    }
                }
            }
            SDL_Delay(50);  // anti-boucle trop rapide
        }
    }

                }
            }
        }



    if (manager.lives <= 0) {
        printf("Game Over ! Score final : %d\n", manager.score);
    } else if (manager.score > 0) {
        printf("Bravo ! Score final : %d\n", manager.score);
    }

    SDL_FreeSurface(background);
    SDL_FreeSurface(btn_image);
    TTF_CloseFont(font);
    SDL_FreeSurface(bg_restart);
    SDL_FreeSurface(btn_restart);

    Mix_FreeChunk(click_sound);
    Mix_CloseAudio();


    TTF_Quit();
    SDL_Quit();
    return 0;
}
