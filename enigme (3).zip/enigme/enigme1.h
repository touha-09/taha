#ifndef ENIGME1_H
#define ENIGME1_H

#include <SDL/SDL.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_rotozoom.h>  // NÉCESSAIRE pour la rotation (SDL_gfx)

#define MAX_QUESTIONS 20
#define MAX_CHOICES 4
#define MAX_TEXT 256

typedef struct {
    char question[MAX_TEXT];
    char choices[MAX_CHOICES][MAX_TEXT];
    int correct_choice;
} Enigme;

typedef struct {
    Enigme questions[MAX_QUESTIONS];
    int total_questions;
    int current_index;
    int score;
    int lives;
    int level;
} EnigmeManager;

int charger_enigmes_depuis_fichier(EnigmeManager *manager, const char *filename);
void afficher_enigme(SDL_Surface *screen, SDL_Surface *bg_img, SDL_Surface *btn_img, TTF_Font *font, Enigme *enigme, SDL_Rect zones[]);
void afficher_enigme_avec_zones(SDL_Surface *screen, SDL_Surface *bg_img, SDL_Surface *btn_img, TTF_Font *font, Enigme *enigme, SDL_Rect zones[]);
int generer_enigme_unique(EnigmeManager *manager);
int verifier_reponse(Enigme *enigme, int choix_utilisateur);
void mettre_a_jour_score(EnigmeManager *manager, int est_correct);
void demarrer_chronometre();
int temps_ecoule();
void reinitialiser_chronometre();
void afficher_resultat(SDL_Surface *screen, TTF_Font *font, int correct);
int afficher_enigme_avec_timer(SDL_Surface *screen, SDL_Surface *bg_img, SDL_Surface *btn_img, SDL_Surface *btn_img_hover, TTF_Font *font, Enigme *enigme, SDL_Rect zones[], int temps_ecoule, int time_limit);



int initialize_sdl(SDL_Surface **screen, const char *title, int width, int height);
SDL_Surface* load_image(const char *path);
TTF_Font* load_font(const char *path, int size);
void cleanup_sdl(SDL_Surface *background, SDL_Surface *btn_image, TTF_Font *font);
void animer_message_zoom(SDL_Surface *screen, const char *message_text, SDL_Color color, const char *background_path);
void afficher_ecran_restart(SDL_Surface *screen, SDL_Surface *bg_restart, SDL_Surface *btn_restart, SDL_Surface *btn_restart_hover, TTF_Font *font, SDL_Rect *zone_restart);

#endif
