#include "fichier.h"

// Fonction pour initialiser SDL et les ressources de fond
void initialiserSDL(SDL_Surface **ecran, background *b1) {
    if (SDL_Init(SDL_INIT_VIDEO | SDL_INIT_AUDIO) < 0) {
        fprintf(stderr, "Echec de l'initialisation de SDL: %s\n", SDL_GetError());
        exit(1);
    }

    // Initialiser SDL_Mixer pour la gestion des sons
    if (Mix_OpenAudio(22050, MIX_DEFAULT_FORMAT, 2, 4096) == -1) {
        printf("Erreur: Impossible d'initialiser SDL_Mixer: %s\n", Mix_GetError());
        exit(1);
    }

    initback(b1);
    *ecran = SDL_SetVideoMode(b1->imgback->w, b1->imgback->h, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    if (*ecran == NULL) {
        fprintf(stderr, "Echec de la création de la fenêtre: %s\n", SDL_GetError());
        exit(1);
    }
}
// Fonction pour initialiser le fond d'écran et la musique
void initback(background *b) {
    // Charger l'image de fond
    b->imgback = IMG_Load("background.png");
    if (!b->imgback) {
        printf("Erreur: Impossible de charger background.png ! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }

    // Initialiser la musique de fond
    b->musique = Mix_LoadMUS("011.mp3");
    if (!b->musique) {
        printf("Erreur: Impossible de charger la musique ! SDL_Error: %s\n", Mix_GetError());
        exit(1);
    }
}

// Fonction pour charger les images des boutons
void chargerImageBouton1(SDL_Surface **image) {
    *image = IMG_Load("start1.png");
    if (*image == NULL) {
        printf("Erreur: Impossible de charger start.png ! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }
}

void chargerImageBouton2(SDL_Surface **image) {
    *image = IMG_Load("seeting1.png");
    if (*image == NULL) {
        printf("Erreur: Impossible de charger setting.png ! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }
}

void chargerImageBouton3(SDL_Surface **image) {
    *image = IMG_Load("high score1.png");
    if (*image == NULL) {
        printf("Erreur: Impossible de charger high score.png ! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }
}

void chargerImageBouton4(SDL_Surface **image) {
    *image = IMG_Load("history1.png");
    if (*image == NULL) {
        printf("Erreur: Impossible de charger history.png ! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }

}

void chargerImageBouton5(SDL_Surface **image) {
    *image = IMG_Load("quit1.png");
    if (*image == NULL) {
        printf("Erreur: Impossible de charger quit.png ! SDL_Error: %s\n", SDL_GetError());
        exit(1);
    }
}

// Fonction pour définir la position d'un bouton
void definirPosition(SDL_Rect *position, int x, int y) {
    position->x = x;
    position->y = y;
}

// Fonction pour afficher le fond d'écran
void afficherback(background b, SDL_Surface *ecran) {        
    SDL_BlitSurface(b.imgback, NULL, ecran, &b.posback);
}

// Fonction pour afficher tous les éléments à l'écran
void afficher(SDL_Surface *ecran, background b1, SDL_Surface **images, SDL_Rect *positions, TTF_Font *font) {
    afficherback(b1, ecran);
    
    for (int i = 0; i < 5; i++) {
        SDL_BlitSurface(images[i], NULL, ecran, &positions[i]);
    }
    
    SDL_Color textColor = {255, 255, 255};                                          //nahitha
    SDL_Surface *surfaceTexte = TTF_RenderText_Solid(font, "", textColor);          //nahitha
    SDL_Rect positiontext = {500, 125};                                             //nahitha
    SDL_BlitSurface(surfaceTexte, NULL, ecran, &positiontext);                      //nahitha
    SDL_FreeSurface(surfaceTexte);
    
    SDL_Flip(ecran);
}

// Fonction pour gérer les événements (clics sur les boutons)
void gererEvenements(int *quitter, SDL_Surface **images, SDL_Rect *positions, Mix_Chunk *clickSound, TTF_Font *font, SDL_Surface *ecran, int *ind) {
    SDL_Event event;
    int x, y;

    while (SDL_PollEvent(&event)) {
        if (event.type == SDL_QUIT || (event.type == SDL_KEYDOWN && event.key.keysym.sym == SDLK_ESCAPE)) {
            *quitter = 0;  // Quitter si on ferme la fenêtre ou appuie sur ESC
        }

        // Vérification du clic de la souris
        if (event.type == SDL_MOUSEBUTTONDOWN) {
            x = event.button.x;
            y = event.button.y;

            // Vérifier si le bouton "Quitter" (button 5) est cliqué
            if (x >= positions[4].x && x <= positions[4].x + images[4]->w &&
                y >= positions[4].y && y <= positions[4].y + images[4]->h) {
                *quitter = 0;  // Si le bouton Quitter est cliqué, quitter le programme
            }

            // Vérifier si le bouton "Histoire" (button 4) est cliqué
            if (x >= positions[3].x && x <= positions[3].x + images[3]->w &&
                y >= positions[3].y && y <= positions[3].y + images[3]->h) {
                *ind =1 ;  // Si le bouton Histoire est cliqué, quitter le programme
            }

            // Jouer le son de clic
            Mix_PlayChannel(-1, clickSound, 0);
        }
    }
}

// Fonction pour libérer les ressources
void nettoyer(SDL_Surface **images, background *b1, TTF_Font *font) {
    for (int i = 0; i < 5; i++) {
        SDL_FreeSurface(images[i]);
    }
    libererback(b1);
    TTF_CloseFont(font);
    TTF_Quit();
    SDL_Quit();
}

// Fonction pour libérer les ressources du fond d'écran
void libererback(background *b) {
    SDL_FreeSurface(b->imgback);
    Mix_FreeMusic(b->musique);
}

SDL_Surface* loadImage(const char* path) {
    SDL_Surface* loaded = IMG_Load(path);
    if (!loaded) return NULL;
    SDL_Surface* optimized = SDL_DisplayFormatAlpha(loaded);
    //SDL_FreeSurface(loaded);
    return optimized;
}

// Mélange les pièces
void shufflePieces(Piece* pieces, int size) {
    srand(time(NULL));
    for (int i = 0; i < size; i++) {
        int j = rand() % size;
        Piece temp = pieces[i];
        pieces[i] = pieces[j];
        pieces[j] = temp;
    }
}

// Affiche un message centré
void showText(SDL_Surface* screen, const char* msg, SDL_Color color) {
    TTF_Font* font = TTF_OpenFont("arial.ttf", 36);
    if (!font) return;
    SDL_Surface* text = TTF_RenderText_Solid(font, msg, color);
    SDL_Rect pos = { (SCREEN_WIDTH - text->w) / 2, (SCREEN_HEIGHT - text->h) / 2 };
    SDL_BlitSurface(text, NULL, screen, &pos);
    SDL_FreeSurface(text);
    TTF_CloseFont(font);
}

// Affiche une image de fin
void displayEndImage(SDL_Surface* screen, const char* path) {
    SDL_Surface* end = loadImage(path);
    if (end) {
        SDL_Surface* zoomed = rotozoomSurface(end, 0, 1.2, 1);
        SDL_Rect pos = { (SCREEN_WIDTH - zoomed->w) / 2, (SCREEN_HEIGHT - zoomed->h) / 2 };
        SDL_BlitSurface(zoomed, NULL, screen, &pos);
        SDL_FreeSurface(end);
        SDL_FreeSurface(zoomed);
    }
}

// Animation simple d’un chrono avec une bande qui défile
void animateTimer(SDL_Surface* screen, int frame) {
    SDL_Rect bar = { 0, 0, frame % SCREEN_WIDTH, 10 };
    SDL_FillRect(screen, &bar, SDL_MapRGB(screen->format, 255, 100, 100));
}

// Détection du clic sur une image
int checkCollision(int x, int y, SDL_Rect rect) {
    return (x >= rect.x && x <= rect.x + rect.w && y >= rect.y && y <= rect.y + rect.h);
}

/*int verifier_reponse(Enigme *enigme, int choix_utilisateur) {
    return choix_utilisateur == enigme->correct_choice;
}

void mettre_a_jour_score(EnigmeManager *manager, int est_correct) {
    if (est_correct) {
        manager->score += 10;
        manager->level += 1;
    } else {
        manager->lives -= 1;
    }
}

void demarrer_chronometre() {
    start_time = time(NULL);
}

int temps_ecoule() {
    return (int)(time(NULL) - start_time);
}




void animer_message_zoom(SDL_Surface *screen, const char *message_text, SDL_Color color, const char *background_path) {
    int min_size = 24;  // taille minimale
    int max_size = 72;  // taille maximale
    int zoom_steps = 20;

    SDL_Surface *background = load_image(background_path);

    for (int i = 0; i < 2; i++) {  // deux cycles : zoom in + zoom out
        for (int step = 0; step <= zoom_steps; step++) {
            int size = min_size + (step * (max_size - min_size)) / zoom_steps;
            double angle = step * (360.0 / zoom_steps);  // rotation complète en un cycle

            TTF_Font *font = load_font("font/THEBOLDFONT.ttf", size);
            SDL_Surface *message = TTF_RenderText_Solid(font, message_text, color);

            // Appliquer la rotation + garder l'échelle normale (zoom = 1.0)
            SDL_Surface *rotated = rotozoomSurface(message, angle, 1.0, 1);

            if (background) {
                SDL_BlitSurface(background, NULL, screen, NULL);
            } else {
                SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));  // fallback noir
            }

            SDL_Rect pos;
            pos.x = (screen->w - rotated->w) / 2;
            pos.y = (screen->h - rotated->h) / 2;
            SDL_BlitSurface(rotated, NULL, screen, &pos);

            SDL_Flip(screen);

            SDL_FreeSurface(message);
            SDL_FreeSurface(rotated);
            TTF_CloseFont(font);
            SDL_Delay(30);
        }

        // zoom out + rotation inverse
        for (int step = zoom_steps; step >= 0; step--) {
            int size = min_size + (step * (max_size - min_size)) / zoom_steps;
            double angle = step * (360.0 / zoom_steps);

            TTF_Font *font = load_font("font/THEBOLDFONT.ttf", size);
            SDL_Surface *message = TTF_RenderText_Solid(font, message_text, color);

            SDL_Surface *rotated = rotozoomSurface(message, angle, 1.0, 1);

            if (background) {
                SDL_BlitSurface(background, NULL, screen, NULL);
            } else {
                SDL_FillRect(screen, NULL, SDL_MapRGB(screen->format, 0, 0, 0));
            }

            SDL_Rect pos;
            pos.x = (screen->w - rotated->w) / 2;
            pos.y = (screen->h - rotated->h) / 2;
            SDL_BlitSurface(rotated, NULL, screen, &pos);

            SDL_Flip(screen);

            SDL_FreeSurface(message);
            SDL_FreeSurface(rotated);
            TTF_CloseFont(font);
            SDL_Delay(30);
        }
    }
*/
