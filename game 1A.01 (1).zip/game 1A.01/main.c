#include "fichier.h"

int main(int argc, char** argv) {
    SDL_Surface *ecran;
    background b1;
    SDL_Surface *images[5];
    SDL_Rect positions[5];
    int quitter = 1;
    Mix_Chunk *clickSound; // Use Mix_Chunk for sound effects
    int indice=0;
    int ind=0;
    int continuer = 1;  // contrôle les écrans

    initialiserSDL(&ecran, &b1);
    ;
    TTF_Init();
    TTF_Font *font = TTF_OpenFont("arial.ttf", 20);
    if (font == NULL) {
        printf("Erreur: Impossible de charger la police: %s\n", TTF_GetError());
        exit(1);
    }

    // Load sound effect using Mix_LoadWAV
    clickSound = Mix_LoadWAV("sonbref (1).wav");
    if (clickSound == NULL) {
        printf("Erreur: Impossible de charger le son: %s\n", Mix_GetError());
        exit(1);
    }
    SDL_WM_SetCaption("Mini Puzzle Game", NULL);

    
    Mix_PlayMusic(b1.musique, -1); // Play background music
    while (continuer) {
        switch (indice) {
            case 0:
            chargerImageBouton1(&images[0]);
            chargerImageBouton2(&images[1]);
            chargerImageBouton3(&images[2]);
            chargerImageBouton4(&images[3]);
            chargerImageBouton5(&images[4]);

            definirPosition(&positions[0], 5, 200);
            definirPosition(&positions[1], 5, 250);
            definirPosition(&positions[2], 5, 300);
            definirPosition(&positions[3], 5, 350);
            definirPosition(&positions[4], 1000, 500);
            while (quitter) {
            afficherback(b1,ecran);
            gererEvenements(&quitter, images, positions, clickSound, font, ecran,&ind);
            afficher(ecran, b1, images, positions, font);
            if (ind == 1) 
            {
                indice = 1;
                quitter = 0;
            }
            
                
            

            
        }
                break;
            case 1:
            SDL_Surface* bg = loadImage("enigme.png");
            SDL_Surface* imgStar = loadImage("kenz.png");
            SDL_Surface* imgBox  = loadImage("kenz2.png");
            SDL_Surface* imgGem  = loadImage("gem.png");
            SDL_Surface* imgBomb = loadImage("bommmb.png");
                // Initialisation des pièces sans boucle
        Piece pieces[4];
        pieces[0] = (Piece){ imgStar, {100, 450, 0, 0}, {100, 100}, 0, 0 };
        pieces[1] = (Piece){ imgBox,  {220, 450, 0, 0}, {220, 100}, 0, 0 };
        pieces[2] = (Piece){ imgGem,  {340, 450, 0, 0}, {340, 100}, 0, 0 };
        pieces[3] = (Piece){ imgBomb, {460, 450, 0, 0}, {460, 100}, 0, 1 }; // Bombe

        shufflePieces(pieces, 4);

        int quit = 0, selected = -1;
        int gameState = 0;
        SDL_Event event;
        int frame = 0;

        while (!quit) {
            while (SDL_PollEvent(&event)) {
                if (event.type == SDL_QUIT)
                    quit = 1;

                if (event.type == SDL_MOUSEBUTTONDOWN && gameState == 0) {
                    int mx = event.button.x;
                    int my = event.button.y;
                    for (int i = 0; i < 4; i++) {
                        if (!pieces[i].isPlaced && checkCollision(mx, my, pieces[i].pos))
                            selected = i;
                    }
                }

                if (event.type == SDL_MOUSEBUTTONUP && selected != -1) {
                    int mx = event.button.x;
                    int my = event.button.y;
                    if (mx >= pieces[selected].target.x && mx <= pieces[selected].target.x + 100 &&
                        my >= pieces[selected].target.y && my <= pieces[selected].target.y + 100) {

                        pieces[selected].pos.x = pieces[selected].target.x;
                        pieces[selected].pos.y = pieces[selected].target.y;
                        pieces[selected].isPlaced = 1;

                        if (pieces[selected].isBomb)
                            gameState = 2; // Perdu
                    }
                    selected = -1;
                }

                if (event.type == SDL_MOUSEMOTION && selected != -1) {
                    pieces[selected].pos.x = event.motion.x - 50;
                    pieces[selected].pos.y = event.motion.y - 50;
                }
            }

            // Vérification de la victoire
            if (gameState == 0) {
                int win = 1;
                for (int i = 0; i < 4; i++) {
                    if (!pieces[i].isPlaced && !pieces[i].isBomb)
                        win = 0;
                }
                if (win)
                    gameState = 1;
            }

            SDL_BlitSurface(bg, NULL, ecran, NULL);
            animateTimer(ecran, frame++);

            for (int i = 0; i < 4; i++)
                SDL_BlitSurface(pieces[i].image, NULL, ecran, &pieces[i].pos);

            if (gameState == 1)
                showText(ecran, "Bravo !", (SDL_Color){0, 255, 0});
            else if (gameState == 2)
                showText(ecran, "Perdu !", (SDL_Color){255, 0, 0});

            if (gameState)
                displayEndImage(ecran, "xxxx.png");

            SDL_Flip(ecran);
            SDL_Delay(30);
        }
                break;
            case 2:
                break;
            case 3:
                
                break;
            case 4:
                
                break;
            default:
                break;
        }
    }
    nettoyer(images, &b1, font);
    Mix_FreeChunk(clickSound); // Free the sound effect
    /*SDL_FreeSurface(bg);
    SDL_FreeSurface(imgStar);
    SDL_FreeSurface(imgBox);
    SDL_FreeSurface(imgGem);
    SDL_FreeSurface(imgBomb);*/
    
    return 0;
}
