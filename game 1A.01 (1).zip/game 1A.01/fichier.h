#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>
#include <SDL/SDL_ttf.h>
#include <SDL/SDL_rotozoom.h>
#include <time.h>


#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600

typedef struct background {
    SDL_Rect posback;
    SDL_Surface *imgback;
    Mix_Music *musique;
} background;

typedef struct bouton {
    SDL_Rect posbouton;
    SDL_Surface *imgbouton[2];
} bouton;
typedef struct {
    SDL_Surface* image;
    SDL_Rect pos;        // Position actuelle
    SDL_Rect target;     // Position cible
    int isPlaced;        // 1 si la pièce est bien placée
    int isBomb;          // 1 si c'est une bombe
} Piece;

void initialiserSDL(SDL_Surface **ecran, background *b1);
void initback(background *b);
void chargerImageBouton1(SDL_Surface **image);
void chargerImageBouton2(SDL_Surface **image);
void chargerImageBouton3(SDL_Surface **image);
void chargerImageBouton4(SDL_Surface **image);
void chargerImageBouton5(SDL_Surface **image);
void definirPosition(SDL_Rect *position, int x, int y);
void afficherback(background b, SDL_Surface *ecran);
void afficher(SDL_Surface *ecran, background b1, SDL_Surface **images, SDL_Rect *positions, TTF_Font *font);
void gererEvenements(int *quitter, SDL_Surface **images, SDL_Rect *positions, Mix_Chunk *clickSound, TTF_Font *font, SDL_Surface *ecran , int *indice);
void nettoyer(SDL_Surface **images, background *b1, TTF_Font *font);
void libererback(background *b);
SDL_Surface* loadImage(const char* path);
void shufflePieces(Piece* pieces, int size);
void showText(SDL_Surface* screen, const char* msg, SDL_Color color);
void displayEndImage(SDL_Surface* screen, const char* path);
void animateTimer(SDL_Surface* screen, int frame);
int checkCollision(int x, int y, SDL_Rect rect);



