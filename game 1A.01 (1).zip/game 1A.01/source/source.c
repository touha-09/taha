#include "fichier.h"
#include <SDL/SDL.h>
#include <SDL/SDL_mixer.h>

int main(int argc, char *argv[]) {
    MenuPrincipal menuPrincipal;
    SubMenuEnigme subMenuEnigme;

    initMenuPrincipal(&menuPrincipal);
    initSubMenu(&subMenuEnigme);

    int running = 1;
    while (running) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = 0;
            }

            // Gérer les interactions du menu principal
            if (event.type == SDL_MOUSEMOTION) {
                menuPrincipal.playHovered = collision_avec_souris(menuPrincipal.posPlayBtn);
                menuPrincipal.quitHovered = collision_avec_souris(menuPrincipal.posQuitBtn);
            }

            if (event.type == SDL_MOUSEBUTTONDOWN) {
                if (menuPrincipal.playHovered) {
                    running = 0;  // Passe au sous-menu
                } else if (menuPrincipal.quitHovered) {
                    running = 0;  // Quitter l'application
                }
            }
        }

        displayMenuPrincipal(&menuPrincipal);
    }

    // Loop principal du sous-menu
    while (running) {
        SDL_Event event;
        while (SDL_PollEvent(&event)) {
            if (event.type == SDL_QUIT) {
                running = 0;
            }
            // Gérer les événements du sous-menu
        }

        displaySubMenu(&subMenuEnigme);
    }

    cleanupMenuPrincipal(&menuPrincipal);
    cleanupSubMenu(&subMenuEnigme);
    return 0;
}

