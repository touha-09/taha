#ifndef HEADER_H
#define HEADER_H

#include <SDL/SDL.h>
#include <SDL/SDL_image.h>

#define SCREEN_WIDTH 800
#define SCREEN_HEIGHT 600
#define NUM_PIECES 3

typedef struct {
    SDL_Surface* image;
    SDL_Rect position;
    int isBomb;
    int dragging;
} PuzzlePiece;

SDL_Surface* loadImage(const char* path);
void initPieces(PuzzlePiece pieces[]);
void drawPieces(SDL_Surface* screen, SDL_Surface* bg, PuzzlePiece pieces[]);
void handleEvents(SDL_Event* event, PuzzlePiece pieces[], int* quit);

#endif